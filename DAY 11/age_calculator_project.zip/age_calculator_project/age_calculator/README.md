# Age Calculator

A classic-UI Age Calculator web app built with **HTML, CSS, JavaScript** (frontend) and **Flask** (backend).

---

## Project Structure

```
age_calculator/
├── app.py                   # Flask backend — routes & age logic
├── requirements.txt
├── templates/
│   └── index.html           # Jinja2 HTML template
└── static/
    ├── css/
    │   └── style.css        # All styling
    └── js/
        └── main.js          # Frontend logic & fetch calls
```

---

## Features

- ✅ Exact age in **Years, Months, Days**
- ✅ Total days, weeks, months, hours, minutes lived
- ✅ Days until next birthday
- ✅ Day of the week you were born
- ✅ Zodiac sign
- ✅ Animated number counter on results
- ✅ Responsive design (mobile-friendly)
- ✅ Input validation on both client and server

---

## Setup & Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the Flask app
```bash
python app.py
```

### 3. Open in browser
```
http://127.0.0.1:5000
```

---

## API Endpoint

### `POST /calculate`

**Request body (JSON):**
```json
{ "dob": "1998-05-14" }
```

**Response (JSON):**
```json
{
  "years": 27,
  "months": 11,
  "days": 21,
  "total_days": 10218,
  "total_weeks": 1459,
  "total_months": 335,
  "total_hours": 245232,
  "total_minutes": 14713920,
  "days_until_birthday": 161,
  "day_of_week": "Thursday",
  "dob_formatted": "May 14, 1998",
  "zodiac": "Taurus ♉"
}
```
