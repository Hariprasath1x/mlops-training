/* ===========================
   Age Calculator — main.js
=========================== */

(function () {
    'use strict';

    // ── DOM refs ──────────────────────────────────────────
    const dobInput        = document.getElementById('dob');
    const calculateBtn    = document.getElementById('calculateBtn');
    const resetBtn        = document.getElementById('resetBtn');
    const errorMsg        = document.getElementById('errorMsg');
    const resultsSection  = document.getElementById('resultsSection');

    // Result elements
    const resYears        = document.getElementById('resYears');
    const resMonths       = document.getElementById('resMonths');
    const resDays         = document.getElementById('resDays');
    const resDobFormatted = document.getElementById('resDobFormatted');

    // Stats
    const statTotalDays     = document.getElementById('statTotalDays');
    const statTotalWeeks    = document.getElementById('statTotalWeeks');
    const statTotalMonths   = document.getElementById('statTotalMonths');
    const statTotalHours    = document.getElementById('statTotalHours');
    const statTotalMinutes  = document.getElementById('statTotalMinutes');
    const statNextBirthday  = document.getElementById('statNextBirthday');

    // Fun facts
    const factDayOfWeek = document.getElementById('factDayOfWeek');
    const factZodiac    = document.getElementById('factZodiac');

    // ── Init ─────────────────────────────────────────────
    // Set max date to today
    dobInput.max = new Date().toISOString().split('T')[0];

    // ── Event Listeners ───────────────────────────────────
    calculateBtn.addEventListener('click', handleCalculate);
    resetBtn.addEventListener('click', handleReset);

    dobInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') handleCalculate();
    });

    // ── Handlers ──────────────────────────────────────────
    function handleCalculate() {
        const dob = dobInput.value;

        clearError();

        if (!dob) {
            showError('Please select a date of birth.');
            return;
        }

        setLoading(true);

        fetch('/calculate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ dob })
        })
        .then(res => res.json())
        .then(data => {
            setLoading(false);
            if (data.error) {
                showError(data.error);
                hideResults();
            } else {
                displayResults(data);
            }
        })
        .catch(() => {
            setLoading(false);
            showError('Something went wrong. Please try again.');
        });
    }

    function handleReset() {
        dobInput.value = '';
        clearError();
        hideResults();
        dobInput.focus();
    }

    // ── Display Results ───────────────────────────────────
    function displayResults(data) {
        // Animate numbers
        animateNumber(resYears,  data.years,   0);
        animateNumber(resMonths, data.months,  120);
        animateNumber(resDays,   data.days,    240);

        resDobFormatted.textContent = 'Born on ' + data.dob_formatted;

        statTotalDays.textContent    = formatNumber(data.total_days);
        statTotalWeeks.textContent   = formatNumber(data.total_weeks);
        statTotalMonths.textContent  = formatNumber(data.total_months);
        statTotalHours.textContent   = formatNumber(data.total_hours);
        statTotalMinutes.textContent = formatNumber(data.total_minutes);

        statNextBirthday.textContent = data.days_until_birthday === 0
            ? '🎉 Today!'
            : data.days_until_birthday;

        factDayOfWeek.textContent = data.day_of_week;
        factZodiac.textContent    = data.zodiac;

        showResults();
    }

    // ── Helpers ───────────────────────────────────────────
    function animateNumber(el, target, delayMs) {
        const duration = 700;
        const start    = performance.now() + delayMs;
        const from     = 0;

        function step(now) {
            if (now < start) { requestAnimationFrame(step); return; }
            const elapsed  = now - start;
            const progress = Math.min(elapsed / duration, 1);
            const eased    = easeOutCubic(progress);
            el.textContent = Math.round(from + (target - from) * eased);
            if (progress < 1) requestAnimationFrame(step);
        }

        requestAnimationFrame(step);
    }

    function easeOutCubic(t) {
        return 1 - Math.pow(1 - t, 3);
    }

    function formatNumber(n) {
        return n.toLocaleString('en-IN');
    }

    function showError(msg) {
        errorMsg.textContent = msg;
        errorMsg.classList.remove('hidden');
    }

    function clearError() {
        errorMsg.textContent = '';
        errorMsg.classList.add('hidden');
    }

    function showResults() {
        resultsSection.classList.remove('hidden');
        resultsSection.classList.add('visible');
        resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function hideResults() {
        resultsSection.classList.add('hidden');
        resultsSection.classList.remove('visible');
    }

    function setLoading(state) {
        calculateBtn.disabled    = state;
        calculateBtn.textContent = state ? 'Calculating…' : 'Calculate Age';
    }

})();
