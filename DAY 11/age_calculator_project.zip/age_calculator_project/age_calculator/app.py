from flask import Flask, render_template, request, jsonify
from datetime import date, datetime

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    try:
        data = request.get_json()
        dob_str = data.get('dob')

        if not dob_str:
            return jsonify({'error': 'Date of birth is required.'}), 400

        dob = datetime.strptime(dob_str, '%Y-%m-%d').date()
        today = date.today()

        if dob > today:
            return jsonify({'error': 'Date of birth cannot be in the future.'}), 400

        years = today.year - dob.year
        months = today.month - dob.month
        days = today.day - dob.day

        if days < 0:
            months -= 1
            # Get days in previous month
            from calendar import monthrange
            prev_month = today.month - 1 if today.month > 1 else 12
            prev_year = today.year if today.month > 1 else today.year - 1
            days += monthrange(prev_year, prev_month)[1]

        if months < 0:
            years -= 1
            months += 12

        # Additional stats
        total_days = (today - dob).days
        total_weeks = total_days // 7
        total_months = years * 12 + months
        total_hours = total_days * 24
        total_minutes = total_hours * 60

        # Next birthday
        try:
            next_birthday = dob.replace(year=today.year)
        except ValueError:
            next_birthday = dob.replace(year=today.year, day=28)

        if next_birthday <= today:
            try:
                next_birthday = dob.replace(year=today.year + 1)
            except ValueError:
                next_birthday = dob.replace(year=today.year + 1, day=28)

        days_until_birthday = (next_birthday - today).days

        # Day of week born
        day_of_week = dob.strftime('%A')

        return jsonify({
            'years': years,
            'months': months,
            'days': days,
            'total_days': total_days,
            'total_weeks': total_weeks,
            'total_months': total_months,
            'total_hours': total_hours,
            'total_minutes': total_minutes,
            'days_until_birthday': days_until_birthday,
            'day_of_week': day_of_week,
            'dob_formatted': dob.strftime('%B %d, %Y'),
            'zodiac': get_zodiac(dob.month, dob.day)
        })

    except ValueError:
        return jsonify({'error': 'Invalid date format.'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500


def get_zodiac(month, day):
    if (month == 3 and day >= 21) or (month == 4 and day <= 19):
        return "Aries ♈"
    elif (month == 4 and day >= 20) or (month == 5 and day <= 20):
        return "Taurus ♉"
    elif (month == 5 and day >= 21) or (month == 6 and day <= 20):
        return "Gemini ♊"
    elif (month == 6 and day >= 21) or (month == 7 and day <= 22):
        return "Cancer ♋"
    elif (month == 7 and day >= 23) or (month == 8 and day <= 22):
        return "Leo ♌"
    elif (month == 8 and day >= 23) or (month == 9 and day <= 22):
        return "Virgo ♍"
    elif (month == 9 and day >= 23) or (month == 10 and day <= 22):
        return "Libra ♎"
    elif (month == 10 and day >= 23) or (month == 11 and day <= 21):
        return "Scorpio ♏"
    elif (month == 11 and day >= 22) or (month == 12 and day <= 21):
        return "Sagittarius ♐"
    elif (month == 12 and day >= 22) or (month == 1 and day <= 19):
        return "Capricorn ♑"
    elif (month == 1 and day >= 20) or (month == 2 and day <= 18):
        return "Aquarius ♒"
    else:
        return "Pisces ♓"


if __name__ == '__main__':
    app.run(debug=True)
